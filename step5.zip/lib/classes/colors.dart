import 'package:flutter/material.dart';


class myColors {
  static const Color Widget_background =  Colors.white;
  static const Color App_bar_color = Colors.white;
  static const Color App_bar_text_color = Colors.greenAccent;
  static const Color Page_title_color = Colors.black;
  static const Color Round_image_background = const Color(0xFF229A98);
  static const Color Image_caption_text_color = Colors.black;
  static const Color Button_text_color = Colors.black;


}